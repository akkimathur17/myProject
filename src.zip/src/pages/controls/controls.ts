import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-controls',
  templateUrl: 'controls.html',
})
export class ControlsPage {

  constructor(public navCtrl: NavController) {
  }

}
